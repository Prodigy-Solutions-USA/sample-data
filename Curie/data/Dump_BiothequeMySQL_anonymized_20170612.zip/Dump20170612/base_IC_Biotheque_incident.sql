-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: guepard    Database: base_IC_Biotheque
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `incident`
--

DROP TABLE IF EXISTS `incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incident` (
  `incident_id` int(11) NOT NULL AUTO_INCREMENT,
  `incident_uniteid` int(11) DEFAULT NULL,
  `incident_com` text,
  `incident_date` date DEFAULT NULL,
  `incident_sup` enum('oui','non') DEFAULT 'non',
  `incident_tempmax` varchar(10) DEFAULT NULL,
  `incident_type` enum('materiel','compn5','compn1') DEFAULT 'materiel',
  PRIMARY KEY (`incident_id`),
  KEY `FK_incident_unite` (`incident_uniteid`),
  CONSTRAINT `FK_incident_unite` FOREIGN KEY (`incident_uniteid`) REFERENCES `unite` (`unite_id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=latin1 COMMENT='incidents';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incident`
--

LOCK TABLES `incident` WRITE;
/*!40000 ALTER TABLE `incident` DISABLE KEYS */;
INSERT INTO `incident` VALUES (1,9,'hémolysé','2007-12-13','non','','materiel'),(2,9,'v','2007-12-11','non','10','materiel'),(3,9,'Hémolysé','2007-12-20','non','','materiel'),(4,9,'HEMOLYSE ++','2008-01-14','non','','materiel'),(5,7,'Couvercle mal positionné : Perte importante d\'Azote .','2008-02-25','non','-180','compn1'),(6,9,'erreur','2008-03-03','oui','','materiel'),(7,9,'prise mal rebranchée lors de travaux le vendredi 24/10/2008 entre 14H13 et 15H13, rebranchée le dimanche 26/10/2008 par le technicien de garde\r\ndétail des températures archivé sur le logiciel Thermotrack ','2008-10-24','non','15.5','compn1'),(8,8,'Incident (1) antérieur à la biothèque susceptible d\'avoir endommagé le tube (ou le tube parent)','2002-04-08','non','-12','materiel'),(9,8,'Incident (2) antérieur à la biothèque susceptible d\'avoir endommagé le tube (ou le tube parent)','2002-10-26','non','-5','materiel'),(10,8,'','2008-05-19','non','20','compn5'),(11,8,'','2008-05-19','non','20','compn5'),(12,8,'','2008-05-19','non','20','compn5'),(13,8,'','2008-05-19','non','20','compn5'),(14,8,'','2008-05-19','non','20','compn5'),(15,8,'','2008-05-19','non','20','compn5'),(16,8,'','2008-05-19','non','20','compn5'),(17,8,'','2008-05-19','non','20','compn5'),(18,8,'','2008-05-19','non','20','compn5'),(19,8,'','2008-05-19','non','20','compn5'),(20,8,'','2008-05-19','non','20','compn5'),(21,8,'','2008-05-19','non','20','compn5'),(22,8,'','2008-05-19','non','20','compn5'),(23,8,'','2008-05-19','non','20','compn5'),(24,8,'','2008-05-19','non','20','compn5'),(25,8,'','2008-05-19','non','20','compn5'),(26,8,'','2008-05-19','non','20','compn5'),(27,8,'','2008-05-19','non','20','compn5'),(28,8,'','2008-05-19','non','20','compn5'),(29,8,'','2008-05-19','non','20','compn5'),(30,8,'','2008-05-19','non','20','compn5'),(31,8,'','2008-05-19','non','20','compn5'),(32,8,'','2008-05-19','non','20','compn5'),(33,8,'','2008-05-19','non','20','compn5'),(34,8,'','2008-05-19','non','20','compn5'),(35,8,'','2008-05-19','non','20','compn5'),(36,8,'','2008-05-19','non','20','compn5'),(37,8,'','2008-05-19','non','20','compn5'),(38,8,'','2008-05-19','non','20','compn5'),(39,8,'','2009-01-14','non','-45','compn5'),(40,8,'','2009-01-14','non','-45','compn5'),(41,8,'','2009-01-14','non','-45','compn5'),(42,8,'','2009-01-14','non','-45','compn5'),(43,8,'','2009-01-14','non','-45','compn5'),(44,8,'','2009-01-14','non','-45','compn5'),(45,8,'','2009-01-14','non','-45','compn5'),(46,8,'','2009-01-14','non','-45','compn5'),(47,8,'','2009-01-14','non','-45','compn5'),(48,8,'','2009-01-14','non','-45','compn5'),(49,8,'','2009-01-14','non','-45','compn5'),(50,8,'','2009-01-14','non','-45','compn5'),(51,8,'','2009-01-14','non','-45','compn5'),(52,8,'','2009-01-14','non','-45','compn5'),(53,8,'','2009-01-14','non','-45','compn5'),(54,8,'','2009-01-14','non','-45','compn5'),(55,8,'','2009-01-14','non','-45','compn5'),(56,8,'','2009-01-14','non','-45','compn5'),(57,8,'','2009-01-14','non','-45','compn5'),(58,8,'','2009-01-14','non','-45','compn5'),(59,8,'','2009-01-14','non','-45','compn5'),(60,8,'','2009-01-14','non','-45','compn5'),(61,8,'','2009-01-14','non','-45','compn5'),(62,8,'','2009-01-14','non','-45','compn5'),(63,8,'','2009-01-14','non','-45','compn5'),(64,8,'','2009-01-14','non','-45','compn5'),(65,8,'','2009-01-14','non','-45','compn5'),(66,8,'','2009-01-14','non','-45','compn5'),(67,8,'','2009-01-14','non','-45','compn5'),(68,8,'','2009-01-14','non','-45','compn5'),(69,8,'','2009-01-14','non','-45','compn5'),(70,8,'','2009-01-14','non','-45','compn5'),(71,8,'','2009-01-14','non','-45','compn5'),(72,8,'','2009-01-14','non','-45','compn5'),(73,8,'','2009-01-14','non','-45','compn5'),(74,8,'','2009-01-14','non','-45','compn5'),(75,8,'','2009-01-14','non','-45','compn5'),(76,8,'','2009-01-14','non','-45','compn5'),(77,8,'','2009-01-14','non','-45','compn5'),(78,8,'','2009-01-14','non','-45','compn5'),(79,8,'','2009-01-14','non','-45','compn5'),(80,8,'','2009-01-14','non','-45','compn5'),(81,8,'','2009-01-14','non','-45','compn5'),(82,8,'Boîte laissée sur un reste de carboglace à temp ambiante une nuit : tubes décongelés.','2009-01-07','non','25','compn5'),(83,9,'contenu du BIO 9 déménagé dans diverses enceintes le temps de la réparation.','2009-07-12','non','-58','compn1'),(84,9,'contenu du BIO 9 déménagé dans diverses enceintes le temps de la réparation.','2009-07-12','oui','-58','compn1'),(85,8,'test','2009-10-09','oui','','materiel'),(86,8,'- 15°','2010-01-06','non','','compn5'),(87,3,'retrouvé décongelé sur paillasse','2010-02-11','non','25','materiel'),(88,4,'Congélateur découvert porte ouverte le 08/04/10.\r\nDate de l\'incident?\r\nCongélateur remonté en température : certains échantillons sont décongelés. Transfert effectué dans le congélateur de secours de biochimie','2010-04-08','non','0','compn1'),(89,8,'décongélation tout le WE, tubes de nouveau à -65°c au bout de 72h','2011-12-05','non','0','compn1'),(90,8,'Ne pas tenir compte de l\'incident appliqué au congélateur A9 à cette date car boîte épargnée','2011-12-05','non','-80','compn5'),(91,8,'','2012-10-19','oui','','materiel'),(92,8,'Tube retrouvé décongelé dans la pièce congélateur du 3ème étage le 17/07/13.\r\nRecongelé pour éventuelle extraction ADN. Ne pas utiliser pour extraction ARN.','2013-07-17','non','25','materiel'),(93,9,'Température atteinet = -68°C\r\nTransfert du contenu (voir fiche de non-conformité du 2/8/13 de S. Saada) le 2/8.\r\nRé-intégration le 6/8','2013-08-02','non','68','compn1'),(94,9,'Température atteinet = -68°C\r\nTransfert du contenu (voir fiche de non-conformité du 2/8/13 de S. Saada) le 2/8.\r\nRé-intégration le 6/8','2013-08-02','non','68','compn1'),(95,9,'Température atteinet = -68°C\r\nTransfert du contenu (voir fiche de non-conformité du 2/8/13 de S. Saada) le 2/8.\r\nRé-intégration le 6/8','2013-08-02','non','','compn1'),(96,9,'Température atteinet = -68°C\r\nTransfert du contenu (voir fiche de non-conformité du 2/8/13 de S. Saada) le 2/8.\r\nRé-intégration le 6/8','2013-08-02','non','','compn1'),(97,9,'Température atteinet = -68°C\r\nTransfert du contenu (voir fiche de non-conformité du 2/8/13 de S. Saada) le 2/8.\r\nRé-intégration le 6/8','2013-08-02','non','','compn1'),(98,8,'Incident technique informatique rencontré lors de l\'enregistrement d\'échantillons dans la boîte. Boîte désactivée, à ne plus utiliser.\r\n\r\nTicket : http://tickets.curie.net/front/ticket.form.php?id=2016010626','2016-01-12','non','','compn5');
/*!40000 ALTER TABLE `incident` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-12 15:39:57
