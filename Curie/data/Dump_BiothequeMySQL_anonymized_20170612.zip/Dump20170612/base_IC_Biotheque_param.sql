-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: guepard    Database: base_IC_Biotheque
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `param`
--

DROP TABLE IF EXISTS `param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `param` (
  `param_id` int(11) NOT NULL AUTO_INCREMENT,
  `param_uniteid` int(11) NOT NULL DEFAULT '0',
  `param_rg001` enum('oui','non') DEFAULT 'oui' COMMENT 'unicité sur compn5 ou compn1+...+compn5',
  `param_rg002` enum('oui','non') DEFAULT 'oui' COMMENT 'gestion des unités',
  `param_rg003` enum('oui','non') DEFAULT 'oui' COMMENT 'les params par défaut sont modifiables ds module action?',
  `param_rg004` enum('oui','non') DEFAULT 'oui' COMMENT 'affichage prel détaillé par défaut (au niveau tube)?',
  `param_rg005` enum('nip','nom','prel') DEFAULT 'nip' COMMENT 'ipp ou num prel en visu ds la case d''un compN5',
  `param_rg006` enum('oui','non') DEFAULT 'oui' COMMENT 'gestion car. matériel dans affichage prel.',
  `param_rg007` enum('oui','non') DEFAULT 'non' COMMENT 'affichage ou non du contenu prel',
  `param_rg008` enum('oui','non') DEFAULT 'non',
  PRIMARY KEY (`param_id`),
  UNIQUE KEY `unicite` (`param_uniteid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COMMENT='valeurs des paramètres généraux de l''application';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `param`
--

LOCK TABLES `param` WRITE;
/*!40000 ALTER TABLE `param` DISABLE KEYS */;
INSERT INTO `param` VALUES (1,9,'oui','non','oui','non','prel','non','oui','oui'),(2,8,'non','oui','oui','oui','prel','oui','oui','non'),(3,7,'oui','oui','oui','non','','non','oui','non'),(4,4,'oui','oui','oui','oui','','non','oui','non'),(5,3,'oui','non','oui','oui','nip','oui','non','oui'),(6,5,'oui','oui','oui','oui','nom','oui','oui','oui'),(7,6,'non','oui','oui','oui','nom','non','oui','oui'),(8,11,'oui','oui','oui','oui','nip','non','non','oui'),(9,99,'non','oui','oui','oui','prel','oui','oui','non');
/*!40000 ALTER TABLE `param` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-12 15:39:57
